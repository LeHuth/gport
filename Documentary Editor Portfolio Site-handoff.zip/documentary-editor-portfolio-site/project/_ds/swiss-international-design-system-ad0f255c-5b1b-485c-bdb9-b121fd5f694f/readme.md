# Swiss International — Design System

A design system built on the **International Typographic Style** (Swiss Design): the grid as the primary organising device, objective sans-serif type set flush-left, a limited palette of black, white and a single signal red, and structure expressed through hairline rules rather than decoration. Light and dark modes are first-class.

> **Brief:** "Swiss International Design — use the Swiss International style, dark and light mode." No codebase, Figma, brand assets, or existing product was supplied. This system is authored **from scratch** in the tradition established by Müller-Brockmann, Hofmann, Ruder and the Neue Grafik school. "Swiss International" is treated as a **design studio** brand; nothing here recreates any real company, product, or trademarked identity.

## Sources
None provided. There is no attached repository, Figma file, or asset pack — every value below is an original interpretation of the published conventions of the Swiss International Typographic Style. If you intended a specific company (e.g. an existing product or the airline of a similar name), attach its codebase, Figma, or brand kit and this system can be re-grounded on it.

---

## CONTENT FUNDAMENTALS

How the brand writes.

- **Voice:** objective, declarative, confident. Statements, not sales. "Order over ornament." "The grid rules." Copy asserts a principle and stops.
- **Person:** first-person plural for the studio ("We build identity, editorial and wayfinding systems"), second person for the reader in product/UI ("Your changes are live"). Never first-person singular.
- **Casing:** display headlines and the wordmark are **UPPERCASE**, tightly tracked. Section labels/eyebrows are uppercase with wide tracking (`.14em`). Body copy is sentence case. Buttons are sentence case by default; uppercase is an available poster treatment.
- **Tone:** terse and precise. Prefer the short Germanic word. Avoid adjectives, hype, and exclamation. No "delightful", "seamless", "powerful".
- **Numbers & data:** set in the monospace stack; coordinates, ratios, indices and years are shown literally (`47.3769° N`, `01 / 12`, `2025`). Numbering things (projects, principles, steps) is a house habit.
- **Emoji:** never. Not in product, marketing, or docs.
- **Punctuation flourish:** the middot `·` is used as the brand separator (`Swiss · Intl`, `Zürich · Basel · Bern`).
- **Examples:** kickers like "Selected Work", "Case Study — 01 / 12"; headlines like "Order over ornament."; microcopy like "We reply within two working days."

---

## VISUAL FOUNDATIONS

- **Colour:** paper white (`--paper #F7F6F3`) and ink black (`--ink #0D0D0D`) carry everything; a single **signal red** (`--red #E4002B`) marks what matters and appears roughly once per view. Blue (`#0B3DFF`) and yellow (`#FFD400`) are the classic Swiss-poster secondary primaries — rare, deliberate accents (large colour fields, data). Neutrals are a cool, near-achromatic grey ramp. **Max one or two colour fields per composition.**
- **Imagery:** typographic first. Swiss posters lead with type and flat colour fields, so hero art is usually a headline or a solid `ink`/`red`/`blue`/`yellow` block, not a photograph. Where photography is used it is **objective, high-contrast black-and-white** (documentary, cool, un-styled, no warm filters, no glow). No gradients as decoration, no illustration, no texture, no grain.
- **Type:** grotesque only — **Archivo** (shipped) standing in for Neue Haas Grotesk / Helvetica / Akzidenz-Grotesk. Display is Black (900) at tight leading (0.9–0.95) and negative tracking; body is Regular at generous leading (1.55); labels are Semibold uppercase with wide tracking. Flush-left, ragged-right is the default setting. Reading measure ~66ch.
- **Layout:** a **12-column grid with 24px gutters** and an **8px baseline** underlie everything; asymmetric, content-led composition. Full-bleed colour bands and edge-to-edge rules are encouraged. Fixed elements: sticky header with a 2px bottom rule; app sidebars are fixed with a 2px right rule.
- **Backgrounds:** flat fills only — `--bg` paper/near-black. No gradients, blurs, or patterns. Occasional full-bleed `ink`/`accent` sections invert the palette.
- **Borders & rules:** the structural language. Hairline `1px` (`--border`) separates rows and cards; `2px` strong rules (`--border-strong`) divide major regions; `4px` heavy accent rules (red) open sections and top cards. Corners are **square** (`--radius-none: 0`); a 2/4px radius exists but is rarely used; pill radius only for switches/dots.
- **Elevation:** flat by default. Shadows are reserved for true overlays (Dialog, Toast, popovers) — never on resting cards, which are defined by border + fill.
- **Cards:** square, `1px` border, no resting shadow, 32px padding; an optional 4px red top rule (`bar`). Variants: default, inverse (ink), accent (red), flat.
- **Transparency & blur:** essentially unused. Scrims behind dialogs are a flat ink wash (`--overlay-scrim`); no glassmorphism.
- **Motion:** objective and quick. Durations 120–280ms on `cubic-bezier(0.2,0,0,1)` (standard) / `(0.16,1,0.3,1)` (entrances). Fades and short translate-ins only — **no bounce, no spring, no parallax.**
- **Hover states:** ghost → subtle surface fill; secondary button → inverts (ink fill, paper text); links → shift to `--link-hover` + underline; interactive card → border darkens to `--border-strong`. Opacity shifts for quiet controls.
- **Press states:** solid controls darken (`--accent-press`); no scale/shrink transform.
- **Focus:** a 2px blue ring offset from the element (`--focus-ring`) — the one place blue is functional.

---

## ICONOGRAPHY

- **Set:** [**Lucide**](https://lucide.dev) line icons — geometric, consistent, open-source (ISC). Their even geometry and open counters suit the Swiss objective feel. **Substitution flag:** no icon set was supplied, so Lucide is a chosen substitute; swap it if the brand has its own.
- **Delivery:** loaded from CDN (`https://unpkg.com/lucide@0.469.0/dist/umd/lucide.js`) — no copied binaries. The `Icon` component reads `window.lucide.icons[Name]` and renders an SVG that inherits `currentColor`.
- **Weight:** system stroke width **1.75** (Lucide default is 2). Icons ride the type baseline and match the optical weight of surrounding text.
- **Usage:** functional and sparing — nav, buttons, affordances. Never decorative, never coloured for effect (they take `currentColor`). Sizes track the control (16 in buttons, 18–20 in nav, 24–26 as standalone).
- **Emoji / unicode as icons:** not used. The only glyph used typographically is the middot `·` separator.
- **Logo:** **none supplied.** Per brand rules we do **not** invent or draw a logo mark. Wherever a mark would sit, the name is set in Archivo Black (see `guidelines/brand-wordmark.card.html`). Provide a real logo and it will replace the wordmark lockups.

---

## Components

Reusable React primitives (`window.SwissInternationalDesignSystem_ad0f25.<Name>`). Grouped by concern; each has a `.d.ts` contract, a `.prompt.md`, and a specimen card.

- **Actions** — `Button`, `IconButton`
- **Forms** — `Input`, `Select`, `Checkbox`, `Radio`, `Switch`
- **Display** — `Card`, `Badge`, `Tag`
- **Navigation** — `Tabs`
- **Overlay** — `Dialog`, `Tooltip`
- **Feedback** — `Toast`
- **Media** — `Icon`

**Intentional additions (no source defined the inventory, so a standard set was authored):** `Icon` is a thin Lucide wrapper added so the glyph set has a typed, brand-consistent entry point. All other components are the conventional from-scratch primitive set sized to this brand.

## UI Kits

- **`ui_kits/studio/`** — editorial studio **marketing site**: Home, Work, Project detail, Studio/About, Contact, Journal. Light/dark toggle.
- **`ui_kits/console/`** — project & asset **management console**: login → sidebar app shell with an Overview dashboard (stat cards + data table) and Settings (forms, dialog, toast).

## Foundations (Design System tab)

Specimen cards live in `guidelines/` and are grouped **Colors**, **Type**, **Spacing**, **Layout**, **Brand**.

---

## Index / Manifest

Root:
- `styles.css` — global entry (import list only). **Consumers link this one file.**
- `readme.md` — this document.
- `SKILL.md` — Agent Skills manifest for download/reuse.
- `thumbnail.html` — homepage tile.

`tokens/` — `colors.css`, `typography.css`, `spacing.css`, `layout.css`, `fonts.css`, `base.css` (semantic aliases + light/dark themes + reset).

`components/` — `actions/`, `forms/`, `display/`, `navigation/`, `overlay/`, `feedback/`, `media/`, plus `lib/inject.js` (internal style-injection helper, not a component).

`guidelines/` — foundation specimen cards.

`ui_kits/studio/`, `ui_kits/console/` — full-screen product recreations, each with its own `README.md`.

## Fonts — substitution flag
The authentic Swiss faces (Neue Haas Grotesk, Helvetica, Akzidenz-Grotesk, Univers) are all licensed. This system ships **Archivo** (Google Fonts, neo-grotesque) as the closest freely-available stand-in, with a `"Helvetica Neue", Helvetica, Arial` fallback. **If you hold a licence for a Helvetica-family grotesque, provide the files and swap `--font-grotesk` in `tokens/typography.css` and the `@font-face`/import in `tokens/fonts.css`.** Because Archivo is loaded via the Google Fonts CSS `@import`, the compiler reports 0 self-hosted `@font-face` rules — that is expected for a CDN font.
