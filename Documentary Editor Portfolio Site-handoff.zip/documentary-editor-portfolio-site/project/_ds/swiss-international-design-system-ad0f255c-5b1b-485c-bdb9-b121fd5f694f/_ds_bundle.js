/* @ds-bundle: {"format":4,"namespace":"SwissInternationalDesignSystem_ad0f25","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"Tag","sourcePath":"components/display/Tag.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Icon","sourcePath":"components/media/Icon.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Dialog","sourcePath":"components/overlay/Dialog.jsx"},{"name":"Tooltip","sourcePath":"components/overlay/Tooltip.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"29e3760dbf54","components/actions/IconButton.jsx":"1eacd893e205","components/display/Badge.jsx":"b0d61bd0bb03","components/display/Card.jsx":"8b84453d2fde","components/display/Tag.jsx":"703330fa8dfa","components/feedback/Toast.jsx":"d313b16ec79b","components/forms/Checkbox.jsx":"8cb9935cfe9c","components/forms/Input.jsx":"830b4b92d895","components/forms/Radio.jsx":"5053a027036e","components/forms/Select.jsx":"9bac4f11a9fc","components/forms/Switch.jsx":"6c6260de17f1","components/lib/inject.js":"4828c0485cf3","components/media/Icon.jsx":"0a2a59f9fa6f","components/navigation/Tabs.jsx":"a314b37276a3","components/overlay/Dialog.jsx":"7173a3732c60","components/overlay/Tooltip.jsx":"0afa38ef78dc","ui_kits/console/AppShell.jsx":"e64e38cf18d0","ui_kits/console/DashboardScreen.jsx":"09bf4ae01b6f","ui_kits/console/LoginScreen.jsx":"cb42186d4771","ui_kits/console/SettingsScreen.jsx":"e563534a37be","ui_kits/studio/Chrome.jsx":"968d709b0581","ui_kits/studio/ContactScreen.jsx":"467cff20d00a","ui_kits/studio/Data.jsx":"4b3f4a5b0160","ui_kits/studio/HomeScreen.jsx":"8a51161e60cf","ui_kits/studio/ProjectScreen.jsx":"1794598b3be8","ui_kits/studio/StudioScreen.jsx":"5b42ad787b74","ui_kits/studio/WorkScreen.jsx":"4c1b26cff7a1"},"inlinedExternals":[],"unexposedExports":[{"name":"injectOnce","sourcePath":"components/lib/inject.js"}]} */

(() => {

const __ds_ns = (window.SwissInternationalDesignSystem_ad0f25 = window.SwissInternationalDesignSystem_ad0f25 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/lib/inject.js
try { (() => {
// Injects a component's scoped stylesheet into <head> exactly once.
// Lowercase export → not exposed on the design-system namespace; imported by
// sibling components so hover/focus/active states can use real CSS selectors
// while keeping the token system as the single source of styling truth.
function injectOnce(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
Object.assign(__ds_scope, { injectOnce });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/lib/inject.js", error: String((e && e.message) || e) }); }

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-btn{--_bd:transparent;display:inline-flex;align-items:center;justify-content:center;gap:8px;font-family:var(--font-grotesk);font-weight:var(--fw-semibold);letter-spacing:.01em;line-height:1;border:var(--border-rule) solid var(--_bd);border-radius:var(--radius-none);cursor:pointer;text-decoration:none;white-space:nowrap;user-select:none;transition:background var(--dur-fast) var(--ease-standard),color var(--dur-fast) var(--ease-standard),border-color var(--dur-fast) var(--ease-standard)}
.si-btn:focus-visible{outline:none;box-shadow:var(--focus-ring)}
.si-btn[disabled],.si-btn[aria-disabled=true]{opacity:.4;pointer-events:none}
.si-btn--sm{font-size:13px;padding:8px 14px}
.si-btn--md{font-size:15px;padding:11px 20px}
.si-btn--lg{font-size:17px;padding:15px 28px}
.si-btn--primary{background:var(--accent);color:var(--text-on-accent)}
.si-btn--primary:hover{background:var(--accent-hover)}
.si-btn--primary:active{background:var(--accent-press)}
.si-btn--secondary{background:transparent;color:var(--text);--_bd:var(--border-strong)}
.si-btn--secondary:hover{background:var(--text);color:var(--bg)}
.si-btn--ghost{background:transparent;color:var(--text)}
.si-btn--ghost:hover{background:var(--surface-2)}
.si-btn--inverse{background:var(--surface-inverse);color:var(--text-inverse)}
.si-btn--inverse:hover{background:var(--accent);color:var(--text-on-accent)}
.si-btn--block{width:100%}
.si-btn--upper{text-transform:uppercase;letter-spacing:var(--tracking-label)}
`;
function Button({
  variant = "primary",
  size = "md",
  block = false,
  uppercase = false,
  iconLeft = null,
  iconRight = null,
  as = "button",
  className = "",
  children,
  ...rest
}) {
  __ds_scope.injectOnce("si-btn", CSS);
  const Tag = as;
  const cls = ["si-btn", `si-btn--${variant}`, `si-btn--${size}`, block ? "si-btn--block" : "", uppercase ? "si-btn--upper" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, rest), iconLeft, children != null && /*#__PURE__*/React.createElement("span", null, children), iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-iconbtn{display:inline-flex;align-items:center;justify-content:center;border:var(--border-rule) solid transparent;border-radius:var(--radius-none);background:transparent;color:var(--text);cursor:pointer;transition:background var(--dur-fast) var(--ease-standard),color var(--dur-fast) var(--ease-standard),border-color var(--dur-fast)}
.si-iconbtn:focus-visible{outline:none;box-shadow:var(--focus-ring)}
.si-iconbtn[disabled]{opacity:.4;pointer-events:none}
.si-iconbtn--sm{width:32px;height:32px}
.si-iconbtn--md{width:40px;height:40px}
.si-iconbtn--lg{width:48px;height:48px}
.si-iconbtn--ghost:hover{background:var(--surface-2)}
.si-iconbtn--secondary{border-color:var(--border-strong)}
.si-iconbtn--secondary:hover{background:var(--text);color:var(--bg)}
.si-iconbtn--primary{background:var(--accent);color:var(--text-on-accent)}
.si-iconbtn--primary:hover{background:var(--accent-hover)}
`;
function IconButton({
  variant = "ghost",
  size = "md",
  label,
  className = "",
  children,
  ...rest
}) {
  __ds_scope.injectOnce("si-iconbtn", CSS);
  const cls = ["si-iconbtn", `si-iconbtn--${variant}`, `si-iconbtn--${size}`, className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    "aria-label": label,
    title: label
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-badge{display:inline-flex;align-items:center;gap:6px;font-family:var(--font-grotesk);font-weight:var(--fw-semibold);font-size:var(--fs-micro);line-height:1;letter-spacing:var(--tracking-label);text-transform:uppercase;padding:5px 8px;border-radius:var(--radius-none);border:var(--border-hair) solid transparent;white-space:nowrap}
.si-badge--solid{background:var(--text);color:var(--bg)}
.si-badge--accent{background:var(--accent);color:var(--text-on-accent)}
.si-badge--outline{background:transparent;color:var(--text);border-color:var(--border-strong)}
.si-badge--muted{background:var(--surface-2);color:var(--text-muted)}
.si-badge--success{background:var(--status-success);color:#fff}
.si-badge--warning{background:var(--status-warning);color:#fff}
.si-badge--danger{background:var(--status-danger);color:#fff}
.si-badge--info{background:var(--status-info);color:#fff}
.si-badge__dot{width:6px;height:6px;border-radius:var(--radius-pill);background:currentColor}
`;
function Badge({
  variant = "solid",
  dot = false,
  className = "",
  children,
  ...rest
}) {
  __ds_scope.injectOnce("si-badge", CSS);
  const cls = ["si-badge", `si-badge--${variant}`, className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    className: "si-badge__dot",
    "aria-hidden": "true"
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-card{position:relative;background:var(--surface);border:var(--border-hair) solid var(--border);border-radius:var(--radius-none);color:var(--text);display:flex;flex-direction:column}
.si-card--pad{padding:var(--pad-card)}
.si-card--inverse{background:var(--surface-inverse);color:var(--text-inverse);border-color:var(--surface-inverse)}
.si-card--accent{background:var(--accent);color:var(--text-on-accent);border-color:var(--accent)}
.si-card--flat{border-color:transparent;background:var(--surface-2)}
.si-card--interactive{cursor:pointer;transition:border-color var(--dur-fast) var(--ease-standard),transform var(--dur-fast) var(--ease-standard)}
.si-card--interactive:hover{border-color:var(--border-strong)}
.si-card__bar{position:absolute;top:0;left:0;right:0;height:var(--border-heavy);background:var(--accent)}
`;
function Card({
  variant = "default",
  padded = true,
  bar = false,
  interactive = false,
  as = "div",
  className = "",
  children,
  ...rest
}) {
  __ds_scope.injectOnce("si-card", CSS);
  const Tag = as;
  const cls = ["si-card", `si-card--${variant}`, padded ? "si-card--pad" : "", bar ? "si-card--bar" : "", interactive ? "si-card--interactive" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, rest), bar && /*#__PURE__*/React.createElement("span", {
    className: "si-card__bar",
    "aria-hidden": "true"
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-tag{display:inline-flex;align-items:center;gap:6px;font-family:var(--font-grotesk);font-weight:var(--fw-medium);font-size:var(--fs-small);line-height:1;padding:6px 10px;border-radius:var(--radius-none);border:var(--border-hair) solid var(--border);background:var(--surface);color:var(--text)}
.si-tag--accent{border-color:var(--accent);color:var(--accent)}
.si-tag--selected{background:var(--text);color:var(--bg);border-color:var(--text)}
.si-tag__x{display:inline-grid;place-items:center;width:16px;height:16px;margin:-2px -4px -2px 0;border:0;background:transparent;color:currentColor;cursor:pointer;opacity:.6;transition:opacity var(--dur-fast)}
.si-tag__x:hover{opacity:1}
`;
function Tag({
  variant = "default",
  onRemove,
  className = "",
  children,
  ...rest
}) {
  __ds_scope.injectOnce("si-tag", CSS);
  const cls = ["si-tag", variant !== "default" ? `si-tag--${variant}` : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "si-tag__x",
    "aria-label": "Remove",
    onClick: onRemove
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 6 6 18M6 6l12 12"
  }))));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const CSS = `
.si-toast{display:flex;align-items:flex-start;gap:14px;background:var(--surface-inverse);color:var(--text-inverse);border-radius:var(--radius-none);padding:16px 16px 16px 0;min-width:300px;max-width:420px;box-shadow:var(--shadow-overlay);font-family:var(--font-grotesk);animation:si-toast-in var(--dur-slow) var(--ease-out)}
.si-toast__accent{align-self:stretch;width:var(--border-heavy);flex:none;background:var(--accent)}
.si-toast__accent--success{background:var(--status-success)}
.si-toast__accent--warning{background:var(--status-warning)}
.si-toast__accent--info{background:var(--status-info)}
.si-toast__body{flex:1;min-width:0;padding-left:2px}
.si-toast__title{font-size:var(--fs-small);font-weight:var(--fw-bold);letter-spacing:var(--tracking-tight);margin-bottom:2px}
.si-toast__msg{font-size:var(--fs-caption);color:var(--text-inverse);opacity:.72;line-height:1.4}
.si-toast__x{flex:none;width:24px;height:24px;display:grid;place-items:center;border:0;background:transparent;color:var(--text-inverse);opacity:.6;cursor:pointer;transition:opacity var(--dur-fast)}
.si-toast__x:hover{opacity:1}
@keyframes si-toast-in{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}
`;
function Toast({
  variant = "default",
  title,
  children,
  onClose,
  className = ""
}) {
  __ds_scope.injectOnce("si-toast", CSS);
  return /*#__PURE__*/React.createElement("div", {
    className: ["si-toast", className].filter(Boolean).join(" "),
    role: "status"
  }, /*#__PURE__*/React.createElement("span", {
    className: `si-toast__accent si-toast__accent--${variant}`,
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    className: "si-toast__body"
  }, title && /*#__PURE__*/React.createElement("div", {
    className: "si-toast__title"
  }, title), children && /*#__PURE__*/React.createElement("div", {
    className: "si-toast__msg"
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    className: "si-toast__x",
    "aria-label": "Dismiss",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 6 6 18M6 6l12 12"
  }))));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-check{display:inline-flex;align-items:flex-start;gap:10px;cursor:pointer;font-family:var(--font-grotesk);font-size:var(--fs-body);color:var(--text);user-select:none}
.si-check[data-disabled=true]{opacity:.45;pointer-events:none}
.si-check input{position:absolute;opacity:0;width:0;height:0}
.si-check__box{flex:none;width:20px;height:20px;margin-top:1px;border:var(--border-rule) solid var(--border-strong);background:var(--field-bg);border-radius:var(--radius-none);display:grid;place-items:center;color:var(--text-on-accent);transition:background var(--dur-fast) var(--ease-standard),border-color var(--dur-fast)}
.si-check__box svg{opacity:0;transition:opacity var(--dur-fast)}
.si-check input:checked+.si-check__box{background:var(--accent);border-color:var(--accent)}
.si-check input:checked+.si-check__box svg{opacity:1}
.si-check input:indeterminate+.si-check__box{background:var(--accent);border-color:var(--accent)}
.si-check input:focus-visible+.si-check__box{box-shadow:var(--focus-ring)}
.si-check__text{line-height:1.35}
.si-check__text small{display:block;color:var(--text-muted);font-size:var(--fs-caption)}
`;
function Checkbox({
  label,
  description,
  disabled = false,
  className = "",
  ...rest
}) {
  __ds_scope.injectOnce("si-check", CSS);
  return /*#__PURE__*/React.createElement("label", {
    className: ["si-check", className].filter(Boolean).join(" "),
    "data-disabled": disabled
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "si-check__box"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  }))), (label || description) && /*#__PURE__*/React.createElement("span", {
    className: "si-check__text"
  }, label, description && /*#__PURE__*/React.createElement("small", null, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-field{display:flex;flex-direction:column;gap:6px;font-family:var(--font-grotesk)}
.si-field__label{font-size:var(--fs-caption);font-weight:var(--fw-semibold);text-transform:uppercase;letter-spacing:var(--tracking-label);color:var(--text-muted)}
.si-field__req{color:var(--accent);margin-left:4px}
.si-input__wrap{display:flex;align-items:stretch;border:var(--border-hair) solid var(--field-border);background:var(--field-bg);border-radius:var(--radius-none);transition:border-color var(--dur-fast) var(--ease-standard),box-shadow var(--dur-fast)}
.si-input__wrap:focus-within{border-color:var(--text);box-shadow:inset 0 0 0 1px var(--text)}
.si-input__wrap[data-invalid=true]{border-color:var(--accent);box-shadow:inset 0 0 0 1px var(--accent)}
.si-input__wrap[data-disabled=true]{opacity:.5;pointer-events:none}
.si-input{flex:1;min-width:0;border:0;outline:none;background:transparent;color:var(--text);font-size:var(--fs-body);padding:11px 14px}
.si-input::placeholder{color:var(--text-subtle)}
.si-input__affix{display:flex;align-items:center;color:var(--text-muted);padding:0 12px;font-size:var(--fs-small)}
.si-input__affix--pre{border-right:var(--border-hair) solid var(--border)}
.si-input__affix--suf{border-left:var(--border-hair) solid var(--border)}
.si-field__hint{font-size:var(--fs-caption);color:var(--text-subtle)}
.si-field__hint[data-invalid=true]{color:var(--accent)}
`;
function Input({
  label,
  hint,
  invalid = false,
  required = false,
  disabled = false,
  prefix = null,
  suffix = null,
  id,
  className = "",
  ...rest
}) {
  __ds_scope.injectOnce("si-field", CSS);
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    className: ["si-field", className].filter(Boolean).join(" ")
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "si-field__label",
    htmlFor: uid
  }, label, required && /*#__PURE__*/React.createElement("span", {
    className: "si-field__req"
  }, "*")), /*#__PURE__*/React.createElement("div", {
    className: "si-input__wrap",
    "data-invalid": invalid,
    "data-disabled": disabled
  }, prefix && /*#__PURE__*/React.createElement("span", {
    className: "si-input__affix si-input__affix--pre"
  }, prefix), /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    className: "si-input",
    disabled: disabled,
    "aria-invalid": invalid
  }, rest)), suffix && /*#__PURE__*/React.createElement("span", {
    className: "si-input__affix si-input__affix--suf"
  }, suffix)), hint && /*#__PURE__*/React.createElement("span", {
    className: "si-field__hint",
    "data-invalid": invalid
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-radio{display:inline-flex;align-items:flex-start;gap:10px;cursor:pointer;font-family:var(--font-grotesk);font-size:var(--fs-body);color:var(--text);user-select:none}
.si-radio[data-disabled=true]{opacity:.45;pointer-events:none}
.si-radio input{position:absolute;opacity:0;width:0;height:0}
.si-radio__dot{flex:none;width:20px;height:20px;margin-top:1px;border:var(--border-rule) solid var(--border-strong);border-radius:var(--radius-pill);background:var(--field-bg);display:grid;place-items:center;transition:border-color var(--dur-fast) var(--ease-standard)}
.si-radio__dot::after{content:"";width:10px;height:10px;border-radius:var(--radius-pill);background:var(--accent);transform:scale(0);transition:transform var(--dur-fast) var(--ease-out)}
.si-radio input:checked+.si-radio__dot{border-color:var(--accent)}
.si-radio input:checked+.si-radio__dot::after{transform:scale(1)}
.si-radio input:focus-visible+.si-radio__dot{box-shadow:var(--focus-ring)}
.si-radio__text{line-height:1.35}
.si-radio__text small{display:block;color:var(--text-muted);font-size:var(--fs-caption)}
`;
function Radio({
  label,
  description,
  disabled = false,
  className = "",
  ...rest
}) {
  __ds_scope.injectOnce("si-radio", CSS);
  return /*#__PURE__*/React.createElement("label", {
    className: ["si-radio", className].filter(Boolean).join(" "),
    "data-disabled": disabled
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "si-radio__dot"
  }), (label || description) && /*#__PURE__*/React.createElement("span", {
    className: "si-radio__text"
  }, label, description && /*#__PURE__*/React.createElement("small", null, description)));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-select__wrap{position:relative;display:flex;align-items:center;border:var(--border-hair) solid var(--field-border);background:var(--field-bg);border-radius:var(--radius-none);transition:border-color var(--dur-fast) var(--ease-standard),box-shadow var(--dur-fast)}
.si-select__wrap:focus-within{border-color:var(--text);box-shadow:inset 0 0 0 1px var(--text)}
.si-select__wrap[data-invalid=true]{border-color:var(--accent);box-shadow:inset 0 0 0 1px var(--accent)}
.si-select__wrap[data-disabled=true]{opacity:.5;pointer-events:none}
.si-select{appearance:none;-webkit-appearance:none;flex:1;border:0;outline:none;background:transparent;color:var(--text);font-family:var(--font-grotesk);font-size:var(--fs-body);padding:11px 40px 11px 14px;cursor:pointer}
.si-select__caret{position:absolute;right:14px;pointer-events:none;color:var(--text-muted)}
`;
function Select({
  label,
  hint,
  invalid = false,
  required = false,
  disabled = false,
  id,
  className = "",
  children,
  ...rest
}) {
  __ds_scope.injectOnce("si-select", CSS);
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    className: ["si-field", className].filter(Boolean).join(" ")
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "si-field__label",
    htmlFor: uid
  }, label, required && /*#__PURE__*/React.createElement("span", {
    className: "si-field__req"
  }, "*")), /*#__PURE__*/React.createElement("div", {
    className: "si-select__wrap",
    "data-invalid": invalid,
    "data-disabled": disabled
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: uid,
    className: "si-select",
    disabled: disabled,
    "aria-invalid": invalid
  }, rest), children), /*#__PURE__*/React.createElement("svg", {
    className: "si-select__caret",
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "m6 9 6 6 6-6"
  }))), hint && /*#__PURE__*/React.createElement("span", {
    className: "si-field__hint",
    "data-invalid": invalid
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.si-switch{display:inline-flex;align-items:center;gap:10px;cursor:pointer;font-family:var(--font-grotesk);font-size:var(--fs-body);color:var(--text);user-select:none}
.si-switch[data-disabled=true]{opacity:.45;pointer-events:none}
.si-switch input{position:absolute;opacity:0;width:0;height:0}
.si-switch__track{flex:none;width:44px;height:24px;border:var(--border-rule) solid var(--border-strong);background:var(--field-bg);border-radius:var(--radius-pill);position:relative;transition:background var(--dur-base) var(--ease-standard),border-color var(--dur-base)}
.si-switch__track::after{content:"";position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:var(--radius-pill);background:var(--border-strong);transition:transform var(--dur-base) var(--ease-out),background var(--dur-base)}
.si-switch input:checked+.si-switch__track{background:var(--accent);border-color:var(--accent)}
.si-switch input:checked+.si-switch__track::after{transform:translateX(20px);background:var(--text-on-accent)}
.si-switch input:focus-visible+.si-switch__track{box-shadow:var(--focus-ring)}
`;
function Switch({
  label,
  disabled = false,
  className = "",
  ...rest
}) {
  __ds_scope.injectOnce("si-switch", CSS);
  return /*#__PURE__*/React.createElement("label", {
    className: ["si-switch", className].filter(Boolean).join(" "),
    "data-disabled": disabled
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "si-switch__track"
  }), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/media/Icon.jsx
try { (() => {
// Thin wrapper over Lucide line icons — the system's chosen glyph set.
// Requires the Lucide UMD to be present on the page:
//   <script src="https://unpkg.com/lucide@0.469.0/dist/umd/lucide.js"></script>
// It reads window.lucide.icons[<PascalName>] (an array of [tag, attrs] child
// nodes) and renders an SVG that inherits currentColor. If Lucide is absent it
// renders a neutral square placeholder rather than throwing.
function toPascal(name) {
  return String(name).replace(/(^|[-_ ])(\w)/g, (_, __, c) => c.toUpperCase());
}
function Icon({
  name,
  size = 20,
  stroke = 1.75,
  className = "",
  style,
  ...rest
}) {
  const lib = typeof window !== "undefined" && window.lucide && window.lucide.icons;
  const node = lib ? lib[toPascal(name)] : null;
  const base = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    className: ["si-icon", className].filter(Boolean).join(" "),
    style: {
      display: "block",
      flex: "none",
      ...style
    },
    "aria-hidden": true,
    ...rest
  };
  if (!Array.isArray(node)) {
    return /*#__PURE__*/React.createElement("svg", base, /*#__PURE__*/React.createElement("rect", {
      x: "3",
      y: "3",
      width: "18",
      height: "18"
    }));
  }
  return /*#__PURE__*/React.createElement("svg", base, node.map((child, i) => {
    const [tag, attrs] = child;
    return React.createElement(tag, {
      key: i,
      ...attrs
    });
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/media/Icon.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
const CSS = `
.si-tabs{display:flex;gap:0;border-bottom:var(--border-rule) solid var(--border);font-family:var(--font-grotesk)}
.si-tab{position:relative;appearance:none;border:0;background:transparent;color:var(--text-muted);font-weight:var(--fw-semibold);font-size:var(--fs-small);letter-spacing:var(--tracking-tight);padding:14px 20px;cursor:pointer;transition:color var(--dur-fast) var(--ease-standard)}
.si-tab:hover{color:var(--text)}
.si-tab[aria-selected=true]{color:var(--text)}
.si-tab[aria-selected=true]::after{content:"";position:absolute;left:0;right:0;bottom:calc(-1 * var(--border-rule));height:var(--border-heavy);background:var(--accent)}
.si-tab:focus-visible{outline:none;box-shadow:var(--focus-ring)}
.si-tab--upper{text-transform:uppercase;letter-spacing:var(--tracking-label);font-size:var(--fs-caption)}
.si-tab[disabled]{opacity:.4;pointer-events:none}
`;
function Tabs({
  items = [],
  value,
  defaultValue,
  onChange,
  uppercase = false,
  className = ""
}) {
  __ds_scope.injectOnce("si-tabs", CSS);
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue ?? items[0]?.value);
  const active = isControlled ? value : internal;
  const select = v => {
    if (!isControlled) setInternal(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: ["si-tabs", className].filter(Boolean).join(" "),
    role: "tablist"
  }, items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.value,
    role: "tab",
    "aria-selected": active === it.value,
    disabled: it.disabled,
    className: ["si-tab", uppercase ? "si-tab--upper" : ""].filter(Boolean).join(" "),
    onClick: () => select(it.value)
  }, it.label)));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Dialog.jsx
try { (() => {
const CSS = `
.si-dialog__scrim{position:fixed;inset:0;background:var(--overlay-scrim);display:grid;place-items:center;padding:24px;z-index:var(--z-overlay);animation:si-dialog-fade var(--dur-base) var(--ease-standard)}
.si-dialog{position:relative;background:var(--surface);color:var(--text);border:var(--border-hair) solid var(--border-strong);border-radius:var(--radius-none);box-shadow:var(--shadow-overlay);width:min(520px,100%);max-height:calc(100vh - 48px);overflow:auto;animation:si-dialog-rise var(--dur-base) var(--ease-out)}
.si-dialog__bar{height:var(--border-heavy);background:var(--accent)}
.si-dialog__head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;padding:28px 28px 0}
.si-dialog__title{font:var(--fw-bold) var(--fs-h4)/var(--lh-heading) var(--font-grotesk);letter-spacing:var(--tracking-tight)}
.si-dialog__body{padding:12px 28px 4px;color:var(--text-muted);line-height:var(--lh-body)}
.si-dialog__foot{display:flex;justify-content:flex-end;gap:12px;padding:24px 28px 28px}
.si-dialog__x{flex:none;width:32px;height:32px;display:grid;place-items:center;border:0;background:transparent;color:var(--text-muted);cursor:pointer;transition:color var(--dur-fast)}
.si-dialog__x:hover{color:var(--text)}
@keyframes si-dialog-fade{from{opacity:0}to{opacity:1}}
@keyframes si-dialog-rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
`;
function Dialog({
  open,
  onClose,
  title,
  bar = true,
  footer = null,
  className = "",
  children
}) {
  __ds_scope.injectOnce("si-dialog", CSS);
  React.useEffect(() => {
    if (!open) return;
    const h = e => e.key === "Escape" && onClose && onClose();
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "si-dialog__scrim",
    onClick: e => e.target === e.currentTarget && onClose && onClose()
  }, /*#__PURE__*/React.createElement("div", {
    className: ["si-dialog", className].filter(Boolean).join(" "),
    role: "dialog",
    "aria-modal": "true",
    "aria-label": title
  }, bar && /*#__PURE__*/React.createElement("div", {
    className: "si-dialog__bar",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    className: "si-dialog__head"
  }, title && /*#__PURE__*/React.createElement("h2", {
    className: "si-dialog__title"
  }, title), /*#__PURE__*/React.createElement("button", {
    className: "si-dialog__x",
    "aria-label": "Close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 6 6 18M6 6l12 12"
  })))), /*#__PURE__*/React.createElement("div", {
    className: "si-dialog__body"
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    className: "si-dialog__foot"
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Tooltip.jsx
try { (() => {
const CSS = `
.si-tt{position:relative;display:inline-flex}
.si-tt__pop{position:absolute;z-index:var(--z-overlay);left:50%;transform:translateX(-50%);background:var(--surface-inverse);color:var(--text-inverse);font-family:var(--font-grotesk);font-size:var(--fs-caption);font-weight:var(--fw-medium);line-height:1.3;letter-spacing:.01em;padding:7px 10px;border-radius:var(--radius-none);white-space:nowrap;pointer-events:none;box-shadow:var(--shadow-popover)}
.si-tt__pop--top{bottom:calc(100% + 8px)}
.si-tt__pop--bottom{top:calc(100% + 8px)}
`;
function Tooltip({
  label,
  side = "top",
  className = "",
  children
}) {
  __ds_scope.injectOnce("si-tt", CSS);
  const [show, setShow] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", {
    className: ["si-tt", className].filter(Boolean).join(" "),
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, children, show && label && /*#__PURE__*/React.createElement("span", {
    className: `si-tt__pop si-tt__pop--${side}`,
    role: "tooltip"
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Tooltip.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/AppShell.jsx
try { (() => {
// Console kit — app shell: fixed sidebar + top bar.
const NS_SH = window.SwissInternationalDesignSystem_ad0f25;
function Sidebar({
  route,
  go
}) {
  const {
    Icon
  } = NS_SH;
  const items = [["overview", "Overview", "layout-dashboard"], ["projects", "Projects", "folder"], ["assets", "Assets", "image"], ["team", "Team", "users"], ["settings", "Settings", "settings"]];
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 232,
      flex: "none",
      background: "var(--surface)",
      borderRight: "2px solid var(--border-strong)",
      display: "flex",
      flexDirection: "column",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 64,
      display: "flex",
      alignItems: "center",
      padding: "0 20px",
      borderBottom: "1px solid var(--border)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 900,
      fontSize: 17,
      letterSpacing: "-0.02em",
      textTransform: "uppercase"
    }
  }, "Swiss", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, "\xB7"), "Console")), /*#__PURE__*/React.createElement("nav", {
    style: {
      padding: 12,
      display: "flex",
      flexDirection: "column",
      gap: 2,
      flex: 1
    }
  }, items.map(([k, label, icon]) => {
    const on = route === k;
    return /*#__PURE__*/React.createElement("a", {
      key: k,
      href: "#",
      onClick: e => {
        e.preventDefault();
        go(k);
      },
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "10px 12px",
        fontSize: 14,
        fontWeight: on ? 600 : 500,
        color: on ? "var(--text)" : "var(--text-muted)",
        background: on ? "var(--surface-2)" : "transparent",
        borderLeft: on ? "3px solid var(--accent)" : "3px solid transparent"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: icon,
      size: 18
    }), " ", label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      borderTop: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 32,
      height: 32,
      background: "var(--ink)",
      color: "var(--paper)",
      display: "grid",
      placeItems: "center",
      fontWeight: 700,
      fontSize: 13
    }
  }, "JT"), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600
    }
  }, "J. Tschichold"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: "var(--text-muted)"
    }
  }, "Studio lead"))));
}
function TopBar({
  title,
  onLogout
}) {
  const {
    Icon,
    IconButton,
    Input,
    Button
  } = NS_SH;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 64,
      flex: "none",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 24,
      padding: "0 28px",
      borderBottom: "1px solid var(--border)",
      background: "var(--bg)"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 22,
      fontWeight: 700,
      letterSpacing: "-0.01em"
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 240
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Search\u2026",
    prefix: /*#__PURE__*/React.createElement(Icon, {
      name: "search",
      size: 16
    })
  })), /*#__PURE__*/React.createElement(IconButton, {
    label: "Notifications"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 18
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: onLogout
  }, "Sign out")));
}
Object.assign(window, {
  ConsoleSidebar: Sidebar,
  ConsoleTopBar: TopBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/DashboardScreen.jsx
try { (() => {
// Console kit — overview / projects with stat cards, tabs, and a data table.
const NS_D = window.SwissInternationalDesignSystem_ad0f25;
function StatCard({
  label,
  value,
  delta,
  up
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      padding: 20,
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      height: 4,
      background: "var(--accent)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.14em",
      color: "var(--text-muted)",
      marginBottom: 12,
      marginTop: 4
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: 40,
      letterSpacing: "-0.03em",
      lineHeight: 1
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontFamily: "var(--font-mono)",
      marginTop: 8,
      color: up ? "var(--status-success)" : "var(--accent)"
    }
  }, up ? "▲" : "▼", " ", delta));
}
function DashboardScreen() {
  const {
    Tabs,
    Badge
  } = NS_D;
  const [tab, setTab] = React.useState("active");
  const rows = [["01", "Neue Grafik", "Kunsthaus Zürich", "Editorial", "live", "active"], ["02", "Verkehrshaus", "Museum of Transport", "Signage", "review", "active"], ["03", "Basel Type Week", "Schule für Gestaltung", "Identity", "draft", "active"], ["04", "Helvetica Now", "Monotype", "Editorial", "live", "archived"], ["05", "SBB Timetable", "Swiss Federal Railways", "System", "live", "archived"]];
  const statusVariant = {
    live: "success",
    review: "warning",
    draft: "muted"
  };
  const shown = rows.filter(r => r[5] === tab);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 16,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Active projects",
    value: "12",
    delta: "2 this month",
    up: true
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Assets",
    value: "1,480",
    delta: "120 added",
    up: true
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "In review",
    value: "3",
    delta: "1 overdue"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Utilisation",
    value: "87%",
    delta: "4% vs Q1",
    up: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 20px"
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    uppercase: true,
    items: [{
      label: "Active",
      value: "active"
    }, {
      label: "Archived",
      value: "archived"
    }]
  })), /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      textAlign: "left"
    }
  }, ["#", "Project", "Client", "Discipline", "Status", ""].map((h, i) => /*#__PURE__*/React.createElement("th", {
    key: i,
    style: {
      padding: "14px 20px",
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.12em",
      color: "var(--text-muted)",
      fontWeight: 600,
      borderBottom: "1px solid var(--border)"
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, shown.map(r => /*#__PURE__*/React.createElement("tr", {
    key: r[0],
    style: {
      borderBottom: "1px solid var(--border-muted)"
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "16px 20px",
      fontFamily: "var(--font-mono)",
      color: "var(--text-muted)"
    }
  }, r[0]), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "16px 20px",
      fontWeight: 600
    }
  }, r[1]), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "16px 20px",
      color: "var(--text-muted)"
    }
  }, r[2]), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "16px 20px",
      color: "var(--text-muted)"
    }
  }, r[3]), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "16px 20px"
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: statusVariant[r[4]],
    dot: r[4] === "live"
  }, r[4])), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "16px 20px",
      textAlign: "right"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault(),
    style: {
      fontSize: 13,
      fontWeight: 600
    }
  }, "Open \u2192"))))))));
}
Object.assign(window, {
  ConsoleDashboard: DashboardScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/DashboardScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/LoginScreen.jsx
try { (() => {
// Console kit — login.
const NS_L = window.SwissInternationalDesignSystem_ad0f25;
function LoginScreen({
  onLogin
}) {
  const {
    Input,
    Button,
    Checkbox,
    Icon
  } = NS_L;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      display: "grid",
      gridTemplateColumns: "1fr 1fr"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ink)",
      color: "var(--paper)",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      padding: 48
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 900,
      fontSize: 20,
      textTransform: "uppercase",
      letterSpacing: "-0.02em"
    }
  }, "Swiss", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, "\xB7"), "Console"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: "clamp(40px,5vw,72px)",
      lineHeight: .9,
      letterSpacing: "-0.03em",
      textTransform: "uppercase"
    }
  }, "Order", /*#__PURE__*/React.createElement("br", null), "over", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, "ornament.")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "rgba(255,255,255,.4)"
    }
  }, "Project & asset management")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 48,
      background: "var(--bg)"
    }
  }, /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      onLogin();
    },
    style: {
      width: "100%",
      maxWidth: 360,
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow"
  }, "Members"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 32,
      fontWeight: 800,
      letterSpacing: "-0.02em",
      marginTop: 8
    }
  }, "Sign in")), /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    type: "email",
    defaultValue: "studio@swiss-intl.ch",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Password",
    type: "password",
    defaultValue: "password",
    required: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Remember me",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault(),
    style: {
      fontSize: 13
    }
  }, "Forgot?")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    type: "submit",
    block: true,
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 16
    })
  }, "Sign in"))));
}
Object.assign(window, {
  ConsoleLogin: LoginScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/SettingsScreen.jsx
try { (() => {
// Console kit — settings: form sections, switch, radio, and a confirm dialog.
const NS_ST = window.SwissInternationalDesignSystem_ad0f25;
function Section({
  title,
  desc,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "280px 1fr",
      gap: 40,
      padding: "28px 0",
      borderBottom: "1px solid var(--border)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 18,
      fontWeight: 700,
      letterSpacing: "-0.01em"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: "var(--text-muted)",
      marginTop: 6,
      lineHeight: 1.5
    }
  }, desc)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 18,
      maxWidth: 440
    }
  }, children));
}
function SettingsScreen() {
  const {
    Input,
    Select,
    Switch,
    Radio,
    Checkbox,
    Button,
    Dialog,
    Toast
  } = NS_ST;
  const [open, setOpen] = React.useState(false);
  const [saved, setSaved] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 28,
      maxWidth: 900
    }
  }, /*#__PURE__*/React.createElement(Section, {
    title: "Workspace",
    desc: "Studio-wide defaults applied to every new project."
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Studio name",
    defaultValue: "Swiss International"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Default discipline",
    defaultValue: "identity"
  }, /*#__PURE__*/React.createElement("option", {
    value: "identity"
  }, "Identity"), /*#__PURE__*/React.createElement("option", {
    value: "editorial"
  }, "Editorial"), /*#__PURE__*/React.createElement("option", {
    value: "wayfinding"
  }, "Wayfinding"))), /*#__PURE__*/React.createElement(Section, {
    title: "Appearance",
    desc: "How the console renders for your account."
  }, /*#__PURE__*/React.createElement(Switch, {
    label: "Dark interface",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Radio, {
    name: "density",
    label: "Comfortable",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "density",
    label: "Compact",
    description: "Tighter rows in tables and lists"
  }))), /*#__PURE__*/React.createElement(Section, {
    title: "Notifications",
    desc: "What lands in your inbox."
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Weekly project digest",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Asset approval requests",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Comment mentions"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      paddingTop: 24
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => {
      setSaved(true);
    }
  }, "Save changes"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: () => setOpen(true)
  }, "Delete workspace")), /*#__PURE__*/React.createElement(Dialog, {
    open: open,
    onClose: () => setOpen(false),
    title: "Delete workspace",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setOpen(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => setOpen(false)
    }, "Delete"))
  }, "This permanently removes the workspace and all 1,480 assets. This action cannot be undone."), saved && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      right: 28,
      bottom: 28,
      zIndex: 1200
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    variant: "success",
    title: "Settings saved",
    onClose: () => setSaved(false)
  }, "Your changes are live.")));
}
Object.assign(window, {
  ConsoleSettings: SettingsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/SettingsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/Chrome.jsx
try { (() => {
// Studio kit — shared header + footer. Swiss editorial chrome.
const NS = window.SwissInternationalDesignSystem_ad0f25;
function Logo({
  onClick
}) {
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onClick && onClick("home");
    },
    style: {
      fontWeight: 900,
      fontSize: 20,
      letterSpacing: "-0.02em",
      textTransform: "uppercase",
      lineHeight: 1,
      color: "var(--text)"
    }
  }, "Swiss", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, "\xB7"), "Intl");
}
function Header({
  route,
  go,
  dark,
  setDark
}) {
  const {
    Icon,
    IconButton
  } = NS;
  const nav = [["work", "Work"], ["studio", "Studio"], ["journal", "Journal"], ["contact", "Contact"]];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 20,
      background: "var(--bg)",
      borderBottom: "2px solid var(--border-strong)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "0 40px",
      height: 72,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    onClick: go
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: 32,
      alignItems: "center"
    }
  }, nav.map(([k, label]) => /*#__PURE__*/React.createElement("a", {
    key: k,
    href: "#",
    onClick: e => {
      e.preventDefault();
      go(k);
    },
    style: {
      fontSize: 13,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.12em",
      color: route === k || route === "project" && k === "work" ? "var(--accent)" : "var(--text)"
    }
  }, label)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 22,
      background: "var(--border)"
    }
  }), /*#__PURE__*/React.createElement(IconButton, {
    label: "Toggle theme",
    onClick: () => setDark(!dark)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: dark ? "sun" : "moon",
    size: 18
  })))));
}
function Footer({
  go
}) {
  const cols = [["Studio", [["work", "Work"], ["studio", "About"], ["journal", "Journal"]]], ["Contact", [["contact", "Enquiries"], ["contact", "Press"], ["contact", "Careers"]]]];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--ink)",
      color: "var(--paper)",
      marginTop: 96
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "64px 40px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1fr 1fr",
      gap: 40,
      borderTop: "4px solid var(--accent)",
      paddingTop: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: 44,
      lineHeight: .9,
      letterSpacing: "-0.02em",
      textTransform: "uppercase"
    }
  }, "Swiss", /*#__PURE__*/React.createElement("br", null), "International"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 20,
      fontSize: 14,
      color: "rgba(255,255,255,.6)",
      maxWidth: "32ch",
      lineHeight: 1.6
    }
  }, "A design studio working in the International Typographic tradition. Z\xFCrich.")), cols.map(([h, links]) => /*#__PURE__*/React.createElement("div", {
    key: h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.14em",
      color: "rgba(255,255,255,.5)",
      marginBottom: 16
    }
  }, h), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: 0,
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, links.map(([k, label], i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go(k);
    },
    style: {
      color: "var(--paper)",
      fontSize: 15
    }
  }, label))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginTop: 48,
      fontSize: 12,
      fontFamily: "var(--font-mono)",
      color: "rgba(255,255,255,.4)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Swiss International"), /*#__PURE__*/React.createElement("span", null, "47.3769\xB0 N \u2014 08.5417\xB0 E"))));
}
Object.assign(window, {
  StudioLogo: Logo,
  StudioHeader: Header,
  StudioFooter: Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/ContactScreen.jsx
try { (() => {
// Studio kit — Contact (interactive form → toast) + a compact Journal list.
const NS_C = window.SwissInternationalDesignSystem_ad0f25;
function ContactScreen() {
  const {
    Input,
    Select,
    Checkbox,
    Button,
    Toast,
    Icon
  } = NS_C;
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "0 40px"
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 64,
      padding: "64px 0"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow"
  }, "Enquiries"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontWeight: 900,
      fontSize: "clamp(40px,6vw,80px)",
      lineHeight: .95,
      letterSpacing: "-0.03em",
      margin: "20px 0 32px"
    }
  }, "Start a", /*#__PURE__*/React.createElement("br", null), "project."), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "4px solid var(--accent)",
      paddingTop: 20,
      display: "flex",
      flexDirection: "column",
      gap: 18,
      maxWidth: 360
    }
  }, [["Email", "studio@swiss-intl.ch"], ["Studio", "Löwenstrasse 12, 8001 Zürich"], ["Telephone", "+41 44 000 00 00"]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.14em",
      color: "var(--text-muted)",
      marginBottom: 4
    }
  }, k), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600
    }
  }, v))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20,
      border: "1px solid var(--border)",
      padding: 32,
      background: "var(--surface)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Name",
    placeholder: "Jan Tschichold",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    type: "email",
    placeholder: "you@studio.ch",
    required: true
  })), /*#__PURE__*/React.createElement(Select, {
    label: "Discipline",
    defaultValue: "identity"
  }, /*#__PURE__*/React.createElement("option", {
    value: "identity"
  }, "Identity"), /*#__PURE__*/React.createElement("option", {
    value: "editorial"
  }, "Editorial"), /*#__PURE__*/React.createElement("option", {
    value: "wayfinding"
  }, "Wayfinding"), /*#__PURE__*/React.createElement("option", {
    value: "digital"
  }, "Digital")), /*#__PURE__*/React.createElement(Input, {
    label: "Budget",
    prefix: "CHF",
    placeholder: "25,000",
    inputMode: "decimal"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Subscribe to the studio dispatch",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    type: "submit",
    block: true,
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 16
    })
  }, "Send enquiry")), sent && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      right: 0,
      bottom: -16,
      transform: "translateY(100%)"
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    variant: "success",
    title: "Enquiry sent",
    onClose: () => setSent(false)
  }, "We reply within two working days.")))));
}
function JournalScreen({
  go
}) {
  const posts = [["Why the grid still wins", "Essay", "8 min"], ["Setting Archivo at display sizes", "Notes", "4 min"], ["A field guide to Swiss signage", "Photo", "6 min"], ["On the single accent colour", "Essay", "5 min"]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "0 40px"
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "64px 0 24px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow"
  }, "Journal"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontWeight: 900,
      fontSize: "clamp(40px,6vw,80px)",
      lineHeight: .95,
      letterSpacing: "-0.03em",
      margin: "20px 0 0"
    }
  }, "Journal")), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: 0,
      borderTop: "4px solid var(--accent)"
    }
  }, posts.map(([t, cat, read], i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault(),
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 160px 100px",
      gap: 16,
      alignItems: "center",
      padding: "28px 0",
      borderBottom: "1px solid var(--border)",
      color: "var(--text)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontSize: "clamp(22px,2.4vw,32px)",
      letterSpacing: "-0.01em"
    }
  }, t), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      textTransform: "uppercase",
      letterSpacing: "0.12em",
      color: "var(--text-muted)"
    }
  }, cat), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 13,
      color: "var(--text-muted)",
      textAlign: "right"
    }
  }, read))))));
}
Object.assign(window, {
  StudioContact: ContactScreen,
  StudioJournal: JournalScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/ContactScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/Data.jsx
try { (() => {
// Studio kit — shared sample content.
window.STUDIO_PROJECTS = [{
  id: "01",
  title: "Neue Grafik",
  client: "Kunsthaus Zürich",
  year: "2025",
  disc: "Editorial",
  tone: "ink"
}, {
  id: "02",
  title: "Verkehrshaus",
  client: "Swiss Museum of Transport",
  year: "2025",
  disc: "Signage",
  tone: "red"
}, {
  id: "03",
  title: "Basel Type Week",
  client: "Schule für Gestaltung",
  year: "2024",
  disc: "Identity",
  tone: "paper"
}, {
  id: "04",
  title: "Helvetica Now",
  client: "Monotype",
  year: "2024",
  disc: "Editorial",
  tone: "blue"
}, {
  id: "05",
  title: "SBB Timetable",
  client: "Swiss Federal Railways",
  year: "2023",
  disc: "System",
  tone: "ink"
}, {
  id: "06",
  title: "Documenta 16",
  client: "Kassel",
  year: "2023",
  disc: "Identity",
  tone: "yellow"
}];
window.STUDIO_TONES = {
  ink: {
    bg: "var(--ink)",
    fg: "#f7f6f3"
  },
  red: {
    bg: "var(--red)",
    fg: "#fff"
  },
  paper: {
    bg: "var(--gray-100)",
    fg: "var(--ink)"
  },
  blue: {
    bg: "var(--blue)",
    fg: "#fff"
  },
  yellow: {
    bg: "var(--yellow)",
    fg: "var(--ink)"
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/Data.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/HomeScreen.jsx
try { (() => {
// Studio kit — Home. Typographic hero + featured work grid + index list.
const NS_H = window.SwissInternationalDesignSystem_ad0f25;
function WorkTile({
  p,
  go,
  big
}) {
  const t = window.STUDIO_TONES[p.tone];
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("project", p);
    },
    style: {
      display: "block",
      textDecoration: "none",
      color: "var(--text)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      background: t.bg,
      color: t.fg,
      aspectRatio: big ? "16/9" : "4/3",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      padding: 24,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      opacity: .8
    }
  }, p.id), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: big ? 64 : 34,
      lineHeight: .92,
      letterSpacing: "-0.02em",
      textTransform: "uppercase"
    }
  }, p.title)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "12px 2px",
      borderTop: "1px solid var(--border)",
      marginTop: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 600
    }
  }, p.client), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text-muted)",
      textTransform: "uppercase",
      letterSpacing: "0.1em"
    }
  }, p.disc, " \xB7 ", p.year)));
}
function HomeScreen({
  go
}) {
  const {
    Badge
  } = NS_H;
  const projects = window.STUDIO_PROJECTS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "0 40px"
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "72px 0 56px",
      borderBottom: "2px solid var(--border-strong)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center",
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "accent"
  }, "Studio"), /*#__PURE__*/React.createElement("span", {
    className: "eyebrow"
  }, "Design in the Swiss tradition \u2014 est. 1998")), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontWeight: 900,
      fontSize: "clamp(56px,9vw,124px)",
      lineHeight: .9,
      letterSpacing: "-0.03em",
      textTransform: "uppercase",
      margin: 0
    }
  }, "Order over", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, "ornament.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 40,
      marginTop: 40,
      maxWidth: 820
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      lineHeight: 1.55,
      color: "var(--text-muted)"
    }
  }, "We build identity, editorial and wayfinding systems on the grid \u2014 objective, legible, and built to last."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      lineHeight: 1.55,
      color: "var(--text-muted)"
    }
  }, "Black, white, and a single red. The designer as a neutral conduit for content."))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "48px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 14,
      textTransform: "uppercase",
      letterSpacing: "0.14em",
      fontWeight: 600
    }
  }, "Selected Work"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("work");
    },
    style: {
      fontSize: 13,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.1em"
    }
  }, "All projects \u2192")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement(WorkTile, {
    p: projects[0],
    go: go,
    big: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: 24
    }
  }, projects.slice(1, 4).map(p => /*#__PURE__*/React.createElement(WorkTile, {
    key: p.id,
    p: p,
    go: go
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "32px 0 0",
      borderTop: "4px solid var(--accent)"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 14,
      textTransform: "uppercase",
      letterSpacing: "0.14em",
      fontWeight: 600,
      marginBottom: 8
    }
  }, "Index"), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: 0
    }
  }, projects.map(p => /*#__PURE__*/React.createElement("li", {
    key: p.id
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("project", p);
    },
    style: {
      display: "grid",
      gridTemplateColumns: "64px 1fr 200px 120px",
      gap: 16,
      alignItems: "center",
      padding: "18px 0",
      borderBottom: "1px solid var(--border)",
      color: "var(--text)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 13,
      color: "var(--text-muted)"
    }
  }, p.id), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: "-0.01em"
    }
  }, p.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text-muted)"
    }
  }, p.client), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      textTransform: "uppercase",
      letterSpacing: "0.1em",
      color: "var(--text-muted)",
      textAlign: "right"
    }
  }, p.disc)))))));
}
Object.assign(window, {
  StudioHome: HomeScreen,
  StudioWorkTile: WorkTile
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/ProjectScreen.jsx
try { (() => {
// Studio kit — Project detail.
const NS_P = window.SwissInternationalDesignSystem_ad0f25;
function ProjectScreen({
  project,
  go
}) {
  const {
    Badge,
    Button,
    Tag,
    Icon
  } = NS_P;
  const p = project || window.STUDIO_PROJECTS[0];
  const t = window.STUDIO_TONES[p.tone];
  const meta = [["Client", p.client], ["Year", p.year], ["Discipline", p.disc], ["Location", "Zürich"]];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "32px 40px 0"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("work");
    },
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      fontSize: 13,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.1em"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-left",
    size: 16
  }), " All work")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "28px 40px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center",
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 14,
      color: "var(--text-muted)"
    }
  }, p.id), /*#__PURE__*/React.createElement(Badge, {
    variant: "accent"
  }, p.disc)), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontWeight: 900,
      fontSize: "clamp(48px,8vw,110px)",
      lineHeight: .9,
      letterSpacing: "-0.03em",
      textTransform: "uppercase",
      margin: 0
    }
  }, p.title)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: t.bg,
      color: t.fg,
      height: 420,
      display: "flex",
      alignItems: "flex-end"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "0 40px 40px",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: "clamp(40px,10vw,180px)",
      lineHeight: .82,
      letterSpacing: "-0.04em",
      textTransform: "uppercase",
      opacity: .9
    }
  }, p.disc))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "56px 40px 0",
      display: "grid",
      gridTemplateColumns: "280px 1fr",
      gap: 56
    }
  }, /*#__PURE__*/React.createElement("aside", null, /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "4px solid var(--accent)",
      paddingTop: 20,
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, meta.map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.14em",
      color: "var(--text-muted)",
      marginBottom: 4
    }
  }, k), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600
    }
  }, v))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap",
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Tag, null, "Grid"), /*#__PURE__*/React.createElement(Tag, null, "Type"), /*#__PURE__*/React.createElement(Tag, null, "Print")))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "62ch"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 24,
      lineHeight: 1.45,
      fontWeight: 500,
      letterSpacing: "-0.01em",
      marginBottom: 24
    }
  }, "A complete visual system built on a rigorous modular grid, set entirely in a single neo-grotesque."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      lineHeight: 1.7,
      color: "var(--text-muted)",
      marginBottom: 16
    }
  }, "The brief called for objectivity: information delivered without decoration, legible at every scale from pocket guide to building-height signage. We established a twelve-column grid and an eight-point baseline, then let the content organise itself within it."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      lineHeight: 1.7,
      color: "var(--text-muted)",
      marginBottom: 32
    }
  }, "Colour is limited to black, white and one signal red \u2014 used only to mark what matters. The result is a system that any hand can extend without drifting from its principles."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-up-right",
      size: 16
    })
  }, "View the full case study"))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "64px 40px 0"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      const list = window.STUDIO_PROJECTS;
      const i = list.findIndex(x => x.id === p.id);
      go("project", list[(i + 1) % list.length]);
    },
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      borderTop: "2px solid var(--border-strong)",
      padding: "28px 0",
      color: "var(--text)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      textTransform: "uppercase",
      letterSpacing: "0.14em",
      color: "var(--text-muted)"
    }
  }, "Next project"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 900,
      fontSize: 34,
      textTransform: "uppercase",
      letterSpacing: "-0.02em"
    }
  }, "Continue \u2192"))));
}
Object.assign(window, {
  StudioProject: ProjectScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/ProjectScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/StudioScreen.jsx
try { (() => {
// Studio kit — About / Studio.
const NS_S = window.SwissInternationalDesignSystem_ad0f25;
function StudioScreen({
  go
}) {
  const {
    Card
  } = NS_S;
  const services = [["01", "Identity", "Marks, systems and guidelines built to be extended by any hand."], ["02", "Editorial", "Books, catalogues and periodicals set on a modular grid."], ["03", "Wayfinding", "Signage and environmental systems, legible at every scale."], ["04", "Digital", "Interfaces and design systems in the same objective tradition."]];
  const facts = [["27", "Years"], ["140+", "Projects"], ["9", "People"], ["12", "Awards"]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "0 40px"
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "72px 0 48px",
      borderBottom: "2px solid var(--border-strong)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow"
  }, "The Studio"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontWeight: 900,
      fontSize: "clamp(40px,6vw,80px)",
      lineHeight: .98,
      letterSpacing: "-0.03em",
      margin: "20px 0 0",
      maxWidth: "18ch"
    }
  }, "A small studio with a ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, "rigorous"), " point of view.")), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 0,
      padding: "40px 0",
      borderBottom: "1px solid var(--border)"
    }
  }, facts.map(([n, l]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      borderRight: "1px solid var(--border)",
      paddingRight: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: 56,
      letterSpacing: "-0.03em",
      lineHeight: 1
    }
  }, n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      textTransform: "uppercase",
      letterSpacing: "0.14em",
      color: "var(--text-muted)",
      marginTop: 8
    }
  }, l)))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "48px 0"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 14,
      textTransform: "uppercase",
      letterSpacing: "0.14em",
      fontWeight: 600,
      marginBottom: 24
    }
  }, "Services"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 24
    }
  }, services.map(([n, t, d]) => /*#__PURE__*/React.createElement(Card, {
    key: n,
    bar: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--accent)",
      marginBottom: 14
    }
  }, n), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 26,
      fontWeight: 700,
      letterSpacing: "-0.01em",
      marginBottom: 10
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.6,
      color: "var(--text-muted)"
    }
  }, d))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "16px 0 0",
      borderTop: "4px solid var(--accent)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "clamp(24px,3vw,38px)",
      lineHeight: 1.25,
      fontWeight: 600,
      letterSpacing: "-0.01em",
      maxWidth: "22ch"
    }
  }, "We believe the grid is not a constraint but a instrument of clarity."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("contact");
    },
    style: {
      fontSize: 15,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.1em"
    }
  }, "Work with us \u2192"))));
}
Object.assign(window, {
  StudioAbout: StudioScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/StudioScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/studio/WorkScreen.jsx
try { (() => {
// Studio kit — Work index with discipline filter.
const NS_W = window.SwissInternationalDesignSystem_ad0f25;
function WorkScreen({
  go
}) {
  const {
    Tabs
  } = NS_W;
  const Tile = window.StudioWorkTile;
  const projects = window.STUDIO_PROJECTS;
  const [filter, setFilter] = React.useState("all");
  const discs = ["all", ...Array.from(new Set(projects.map(p => p.disc)))];
  const shown = filter === "all" ? projects : projects.filter(p => p.disc === filter);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "0 40px"
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "64px 0 32px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow"
  }, projects.length, " projects \u2014 2023 to 2025"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontWeight: 900,
      fontSize: "clamp(48px,7vw,96px)",
      lineHeight: .92,
      letterSpacing: "-0.03em",
      textTransform: "uppercase",
      margin: "20px 0 0"
    }
  }, "Work")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: filter,
    onChange: setFilter,
    uppercase: true,
    items: discs.map(d => ({
      label: d === "all" ? "All" : d,
      value: d
    }))
  })), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "40px 32px",
      paddingBottom: 32
    }
  }, shown.map(p => /*#__PURE__*/React.createElement(Tile, {
    key: p.id,
    p: p,
    go: go,
    big: true
  }))));
}
Object.assign(window, {
  StudioWork: WorkScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/studio/WorkScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Tooltip = __ds_scope.Tooltip;

})();
